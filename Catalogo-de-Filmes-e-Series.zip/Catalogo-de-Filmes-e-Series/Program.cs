using System;
using System.Runtime.CompilerServices;

class Program
{
    static void Main(string[] args)
    {
        Menu menu = new Menu();
        menu.MenuLogin();
    }
}
